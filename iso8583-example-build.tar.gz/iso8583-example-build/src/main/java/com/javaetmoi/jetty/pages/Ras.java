package com.javaetmoi.jetty.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Ras extends HttpServlet {
	//POST
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<center>");
		out.print("POS");
		out.print("</center>");
		out.flush();
		out.close();

	}
	//GET
	public void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//ID id = new ID();
		out.print("<center>");
		out.print("<img href=\"https://media.giphy.com/media/3ohzdQ1IynzclJldUQ/source.gif\">");
		out.print("</center>");
		out.flush();
		out.close();
	}
}
