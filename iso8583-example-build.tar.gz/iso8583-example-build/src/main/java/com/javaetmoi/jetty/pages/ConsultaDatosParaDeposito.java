package com.javaetmoi.jetty.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class ConsultaDatosParaDeposito extends HttpServlet {

	static Logger LOGGER = Logger.getLogger(ConsultaDatosParaDeposito.class);

	// POST
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		LOGGER.info("WS POST");
		response.getWriter().write("WS - POST");

	}

	// GET
	public void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		LOGGER.info("WS GET");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// ID id = new ID();
		String html = "<html>" + "<head>"
				+ "    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\" integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">"
				+ "      <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>"
				+ "      <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js\" integrity=\"sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q\" crossorigin=\"anonymous\"></script>"
				+ "      <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js\" integrity=\"sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl\" crossorigin=\"anonymous\"></script>"
				+ "    </head>" 
				+ "    <body>" 
				+"  <div class=\"container-fluid\">"
				+ "      <nav>" 
				+ "        <center>" 
				+ "          <h1>"
				+ "            <img style=\"width:50px\" src=\"imgs/pos.png\">Simulador P.O.S</h1>"
				+ "          </center>" 
				+ "        </nav>" 
				+ "        <nav>" 
				+ "<form name=\"buscador\"  action=\"ras\" method=\"post\" autocomplete=\"off\">" 
				+ "  <div class=\"form-group\">"
				+ "    <label for=\"exampleFormControlSelect1\">Ruts Clientes | Cuenta</label>"
				+ "    <select class=\"form-control\" id=\"exampleFormControlSelect1\">" 
				+ "      <option>111111111-1 | 72443774</option>" 
				+ "      <option>222222222-2 | 87609807</option>" 
				+ "      <option>333333333-3 | 45267533</option>"
				+ "    </select>" 
				+ "  </div>"
				+ "  <div class=\"form-group\">"
				+ "    <label for=\"exampleFormControlInput1\">Monto de la transacci&oacute;n</label>"
				+ "    <input type=\"text\" class=\"form-control\" id=\"exampleFormControlInput1\">"
				+ "  </div>" 
				+" <table>"
				+" <tr>"
				+" <td><button onclick=\"window.location.href='/'\" type=\"button\" class=\"btn btn-danger\">Cancelar</button></td>"
				+" <td><button type=\"button\" class=\"btn btn-warning\">Borrar</button></td>"
				+" <td><button type= \"submit\" class=\"btn btn-success\">Enviar</button></td>"
				+" </tr>"
				+" </table>"
				+ "</form>" 
				+ "</nav>"
				+" </div>"
				+ "      </body>" 
				+ "    </html>";
		out.print(html);
		out.flush();
		out.close();
	}

}
