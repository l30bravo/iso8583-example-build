https://github.com/arey/embedded-jetty-webapp


# P.O.S Simulator #
Este proyecto muestra es una aplicación web Java WAR con Jetty.

Necesita una JVM única para iniciar la aplicación web. No se requiere contenedor web o servidor JEE.

En lugar de crear un archivo war, se genera un archivo JAR autoejecutable con Maven (es decir, jetty-webapp-1.0.0-SNAPSHOT.jar)

Este JAR contiene todos los recursos requeridos por una aplicación web: web.xml, index.jsp, images, js, css ...
La clase JettyServer proporciona un método de inicio y otro de detención. Su método principal inicia el servidor. Para detenerlo, puede usar la clase Stop.

Gracias al [Application Assembler Maven Plugin] (http://mojo.codehaus.org/appassembler/appassembler-maven-plugin/) hay disponibles un script start.sh y stop.sh.

Todas las dependencias JAR están disponibles en un subdirectorio lib \.



## Start the web application

```
target/appassembler/bin/start.sh &
```

## Stop the web application

```
target/appassembler/bin/stop.sh
```

Browse to [http://localhost:8080/HelloWorld](http://localhost:8080/HelloWorld)

## Web port could be changed at startup:

```
target/appassembler/bin/start.sh 80 8090 &
```

## Another possibility is to build a JAR that include all its dependencies (web app, jetty dependencies, logger, spring ...) :
```
mvn clean install -Pfatjar
java -jar target/jetty-webapp-1.0.0-SNAPSHOT-jar-with-dependencies.jar
java -cp target/jetty-webapp-1.0.0-SNAPSHOT-jar-with-dependencies.jar com.javaetmoi.jetty.Stop
```

## Configuration rules ##

Compared to the [Maven Standard Directory Layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html)
of a WAR, the web application sources is not put into the ```src/main/webapp``` but into the ```src/main/resources/webapp```.
Thus the webapp resources are copied into the JAR in a webapp/ sub-directory.

## Credits ##

* Uses [Maven](http://maven.apache.org/) as a build tool
* Uses [Maven Jetty plugin](https://github.com/eclipse/jetty.project) source code
